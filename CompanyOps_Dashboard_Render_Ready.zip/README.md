# CompanyOps Dashboard — shanasoljar

A local portfolio dashboard with overview, employees, projects, analytics, tasks, and an admin profile. The ML Learning Lab has been removed from this version.

## Setup in VS Code (Windows)
1. Extract this ZIP into a new folder.
2. Open the folder that contains `main.py` and `requirements.txt` in VS Code.
3. Open Terminal > New Terminal.
4. Run:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   .\.venv\Scripts\python.exe -m uvicorn main:app --reload
   ```
5. Open http://127.0.0.1:8000 in your browser.

## Notes
- This is a local portfolio/demo dashboard.
- Employee and project demo data may be kept in browser memory; this is not a multi-user database-backed production system.
- Do not upload confidential company data.
